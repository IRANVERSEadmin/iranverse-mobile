// src/screens/auth/AuthWelcomeScreen.tsx
// IRANVERSE Enterprise Authentication Welcome - Revolutionary Gateway Experience
// Tesla-inspired authentication entry point with seamless UX
// Built for 90M users - Enterprise Performance & Accessibility
import React, { useEffect, useRef, useCallback, useState } from 'react';
import {
  View,
  StyleSheet,
  Animated,
  Dimensions,
  Platform,
  BackHandler,
  TouchableOpacity,
} from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

// IRANVERSE Components - Using React Native base components for reliability
import SafeArea from '../../components/ui/SafeArea';
import GradientBackground from '../../components/ui/GradientBackground';
import Text from '../../components/ui/Text';

// ========================================================================================
// TYPES & INTERFACES - ENTERPRISE AUTHENTICATION SYSTEM
// ========================================================================================

type RootStackParamList = {
  AuthWelcome: undefined;
  Login: { 
    email?: string;
    redirectPath?: string;
  };
  Signup: undefined;
  First: undefined;
};

type AuthWelcomeScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'AuthWelcome'>;

interface AuthWelcomeState {
  isReady: boolean;
  toastVisible: boolean;
  toastMessage: string;
  isNavigating: boolean;
}

// ========================================================================================
// AUTH WELCOME SCREEN - REVOLUTIONARY GATEWAY
// ========================================================================================

const AuthWelcomeScreen: React.FC = () => {
  // Navigation
  const navigation = useNavigation<AuthWelcomeScreenNavigationProp>();

  // Screen Dimensions
  const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

  // Component State
  const [state, setState] = useState<AuthWelcomeState>({
    isReady: false,
    toastVisible: false,
    toastMessage: '',
    isNavigating: false,
  });

  // Animation Values with cleanup
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const logoAnim = useRef(new Animated.Value(0)).current;
  const buttonAnim = useRef(new Animated.Value(0)).current;

  // Cleanup effect
  useEffect(() => {
    return () => {
      fadeAnim.stopAnimation();
      scaleAnim.stopAnimation();
      slideAnim.stopAnimation();
      logoAnim.stopAnimation();
      buttonAnim.stopAnimation();
      fadeAnim.removeAllListeners();
      scaleAnim.removeAllListeners();
      slideAnim.removeAllListeners();
      logoAnim.removeAllListeners();
      buttonAnim.removeAllListeners();
    };
  }, [fadeAnim, scaleAnim, slideAnim, logoAnim, buttonAnim]);

  // ========================================================================================
  // NAVIGATION HANDLERS - ENTERPRISE FLOW CONTROL
  // ========================================================================================

  const handleLoginPress = useCallback(() => {
    if (state.isNavigating) return;

    setState(prev => ({ ...prev, isNavigating: true }));

    // Haptic feedback
    if (Platform.OS !== 'web') {
      try {
        const { Vibration } = require('react-native');
        Vibration.vibrate(50);
      } catch (error) {
        console.warn('Haptic feedback error:', error);
      }
    }

    // Animate out and navigate
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 0.7,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      navigation.navigate('Login', {});
      setState(prev => ({ ...prev, isNavigating: false }));
    });
  }, [state.isNavigating, navigation, fadeAnim, scaleAnim]);

  const handleSignupPress = useCallback(() => {
    if (state.isNavigating) return;

    setState(prev => ({ ...prev, isNavigating: true }));

    // Haptic feedback
    if (Platform.OS !== 'web') {
      try {
        const { Vibration } = require('react-native');
        Vibration.vibrate(50);
      } catch (error) {
        console.warn('Haptic feedback error:', error);
      }
    }

    // Animate out and navigate
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 0.7,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      navigation.navigate('Signup', undefined);
      setState(prev => ({ ...prev, isNavigating: false }));
    });
  }, [state.isNavigating, navigation, fadeAnim, scaleAnim]);

  const handleGoBack = useCallback(() => {
    navigation.navigate('First', undefined);
  }, [navigation]);

  // Android back button handling
  useFocusEffect(
    useCallback(() => {
      const onBackPress = () => {
        handleGoBack();
        return true;
      };

      const subscription = BackHandler.addEventListener('hardwareBackPress', onBackPress);
      return () => subscription.remove();
    }, [handleGoBack])
  );

  // ========================================================================================
  // LIFECYCLE EFFECTS - ENTERPRISE INITIALIZATION
  // ========================================================================================

  // Tesla-inspired entrance animation sequence
  useEffect(() => {
    const startEntranceAnimation = () => {
      // Staggered animation sequence for premium feel
      Animated.sequence([
        // Logo appears first
        Animated.timing(logoAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        // Card content fades in
        Animated.parallel([
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 600,
            useNativeDriver: true,
          }),
          Animated.spring(scaleAnim, {
            toValue: 1,
            tension: 400,
            friction: 10,
            useNativeDriver: true,
          }),
          Animated.timing(slideAnim, {
            toValue: 0,
            duration: 600,
            useNativeDriver: true,
          }),
        ]),
        // Buttons appear with slight delay for premium feel
        Animated.timing(buttonAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
      ]).start(() => {
        setState(prev => ({ ...prev, isReady: true }));
      });
    };

    // Small delay for dramatic effect
    const timer = setTimeout(startEntranceAnimation, 200);
    return () => clearTimeout(timer);
  }, [fadeAnim, scaleAnim, slideAnim, logoAnim, buttonAnim]);

  // ========================================================================================
  // RENDER HELPERS - ENTERPRISE UI COMPONENTS
  // ========================================================================================

  const renderLogo = () => (
    <Animated.View
      style={[
        styles.logoContainer,
        {
          opacity: logoAnim,
          transform: [
            {
              scale: logoAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0.5, 1],
              }),
            },
            {
              translateY: logoAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [30, 0],
              }),
            },
          ],
        },
      ]}
    >
      {/* IRANVERSE Logo */}
      <View style={styles.logoWrapper}>
        <Text style={styles.logoText}>
          IRANVERSE
        </Text>
        <View style={styles.logoUnderline} />
      </View>
      
      {/* Tagline */}
      <Text style={styles.tagline}>
        Revolutionary Metaverse Experience
      </Text>
    </Animated.View>
  );

  const renderWelcomeCard = () => (
    <Animated.View
      style={[
        styles.cardContainer,
        {
          opacity: fadeAnim,
          transform: [
            { scale: scaleAnim },
            { translateY: slideAnim },
          ],
        },
      ]}
    >
      <View style={styles.welcomeCard}>
        {/* Welcome Content */}
        <Text style={styles.welcomeTitle}>
          Welcome to IRANVERSE
        </Text>
        
        <Text style={styles.welcomeSubtitle}>
          Join the revolutionary metaverse experience where digital identity meets infinite possibilities.
        </Text>

        {/* Authentication Options */}
        <Animated.View
          style={[
            styles.authButtonsContainer,
            {
              opacity: buttonAnim,
              transform: [
                {
                  translateY: buttonAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [20, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <TouchableOpacity
            style={[styles.loginButton, state.isNavigating && styles.buttonDisabled]}
            onPress={handleLoginPress}
            disabled={state.isNavigating}
            accessibilityLabel="Login to IRANVERSE"
          >
            <Text style={styles.loginButtonText}>
              Log In
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.signupButton, state.isNavigating && styles.buttonDisabled]}
            onPress={handleSignupPress}
            disabled={state.isNavigating}
            accessibilityLabel="Create IRANVERSE account"
          >
            <Text style={styles.signupButtonText}>
              Sign Up
            </Text>
          </TouchableOpacity>
        </Animated.View>

        {/* Additional Info */}
        <Text style={styles.additionalInfo}>
          Experience the future of digital interaction
        </Text>
      </View>
    </Animated.View>
  );

  const renderBackground = () => (
    <View style={styles.backgroundElements}>
      {/* Animated background particles */}
      <View style={styles.particle1} />
      <View style={styles.particle2} />
      <View style={styles.particle3} />
    </View>
  );

  // ========================================================================================
  // MAIN RENDER - ENTERPRISE LAYOUT
  // ========================================================================================

  return (
    <SafeArea edges={['top', 'bottom']} style={styles.container}>
      <GradientBackground animated={true}>
        {/* Background Elements */}
        {renderBackground()}
        
        {/* Main Content */}
        <View style={styles.content}>
          {/* Logo Section */}
          {renderLogo()}
          
          {/* Welcome Card */}
          {renderWelcomeCard()}
        </View>
      </GradientBackground>
    </SafeArea>
  );
};

// ========================================================================================
// STYLES - TESLA-INSPIRED DESIGN
// ========================================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 40,
  },
  backgroundElements: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  particle1: {
    position: 'absolute',
    top: '20%',
    left: '10%',
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  particle2: {
    position: 'absolute',
    top: '60%',
    right: '15%',
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(138, 92, 246, 0.2)',
  },
  particle3: {
    position: 'absolute',
    bottom: '30%',
    left: '20%',
    width: 3,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: 'rgba(0, 255, 133, 0.15)',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  logoWrapper: {
    alignItems: 'center',
    marginBottom: 8,
  },
  logoText: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#FFFFFF',
    letterSpacing: 4,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  logoUnderline: {
    width: 120,
    height: 3,
    backgroundColor: '#00FF85',
    marginTop: 8,
    borderRadius: 1.5,
    shadowColor: '#00FF85',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 8,
  },
  tagline: {
    color: 'rgba(255, 255, 255, 0.7)',
    textAlign: 'center',
    letterSpacing: 1,
    fontStyle: 'italic',
    fontSize: 14,
  },
  cardContainer: {
    width: '100%',
    maxWidth: 400,
  },
  welcomeCard: {
    padding: 32,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 15,
  },
  welcomeTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
    color: '#FFFFFF',
    letterSpacing: 1,
  },
  welcomeSubtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
    paddingHorizontal: 8,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  authButtonsContainer: {
    width: '100%',
    gap: 16,
    marginBottom: 24,
  },
  loginButton: {
    width: '100%',
    backgroundColor: '#8A5CF6',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#8A5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
  signupButton: {
    width: '100%',
    backgroundColor: 'transparent',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  signupButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  additionalInfo: {
    textAlign: 'center',
    opacity: 0.6,
    fontStyle: 'italic',
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.6)',
  },
});

export default AuthWelcomeScreen;